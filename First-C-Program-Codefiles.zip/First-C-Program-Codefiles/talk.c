// My First C Program
#include <stdio.h>
int main()
{
   printf("Talk To a Teacher\n");
   return 0;
}

